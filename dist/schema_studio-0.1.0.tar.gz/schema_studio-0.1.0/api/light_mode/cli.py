"""CLI entrypoint for Schema Studio Light Mode."""
from __future__ import annotations

import threading
import time
from urllib.request import urlopen
import os
import webbrowser
import uvicorn

from .app import app, DEFAULT_HOST, DEFAULT_PORT

BANNER = "Running in Light Mode (local, single-user, non-production; schema pinned to nomad-simulations/develop)"


def _open_browser_when_ready(url: str, timeout_seconds: float = 20.0) -> None:
    """
    Wait for the app to be reachable before opening a browser tab.
    This avoids the initial "page not found" race on startup.
    """
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        try:
            with urlopen(f"{url}/health", timeout=1.0) as resp:
                if 200 <= getattr(resp, "status", 500) < 500:
                    webbrowser.open(url)
                    return
        except Exception:
            time.sleep(0.2)
    # Fallback: open anyway if readiness check timed out.
    webbrowser.open(url)


def main() -> None:
    url = f"http://{DEFAULT_HOST}:{DEFAULT_PORT}"
    print(BANNER)
    print(f"Launching browser at {url} when server is ready\n")
    threading.Thread(target=_open_browser_when_ready, args=(url,), daemon=True).start()

    uvicorn.run(app, host=DEFAULT_HOST, port=DEFAULT_PORT, log_level=os.getenv("UVICORN_LOG_LEVEL", "info"))


if __name__ == "__main__":
    main()
